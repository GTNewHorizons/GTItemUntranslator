package com.mrteroblaze.travelanchorfix.server;

import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;

public class ServerProxy {

    public void preInit(FMLPreInitializationEvent event) {
        // nothing for server
    }

    public void init(FMLInitializationEvent event) {
        // nothing for server
    }
}
